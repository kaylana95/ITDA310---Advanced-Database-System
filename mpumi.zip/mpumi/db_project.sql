-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 14, 2020 at 02:18 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_project`
--
CREATE DATABASE IF NOT EXISTS `db_project` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `db_project`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `appoint_add`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `appoint_add` (IN `patID` INT, IN `staffInfo` VARCHAR(255), IN `clinID` INT, IN `type` VARCHAR(255), IN `reason` VARCHAR(255), IN `Ddate` DATETIME)  NO SQL
BEGIN
    DECLARE Adate datetime;
	SET Adate = (SELECT a.date FROM Appointment a WHERE (DATE(a.date) = DATE(Ddate) AND TIME(a.date) BETWEEN TIMESTAMPADD(MINUTE,-30,TIME(Ddate)) AND TIME(Ddate)) OR (DATE(a.date) = DATE(Ddate) AND TIME(a.date) BETWEEN TIME(Ddate) AND TIMESTAMPADD(MINUTE,30, TIME(Ddate))) LIMIT 1);

    IF Adate IS NULL THEN
		INSERT INTO Appointment(patID, staffInfo, clinID, nurseID, type, reason, date)VALUES(patID, staffInfo, clinID, (SELECT nurseID FROM Nurse ORDER BY RAND() LIMIT 1), type, reason, Ddate);
		IF (SELECT ROW_COUNT()) = 1 THEN 
    		SELECT CONCAT('Appointment was successfully scheduled TO: ', Ddate) AS result;
        ELSE
        	SELECT 'Error occurred' AS result;
        END IF;
    ELSE
    	SELECT CONCAT('There is already an appointment scheduled TO: ', Adate, '. Therefore, the possible available spots are: ', TIMESTAMPADD(MINUTE,-35,TIME(Adate)), ' (30 minutes early) OR ', TIMESTAMPADD(MINUTE,35,TIME(Adate)), ' (30 minutes after)' ) AS result, Ddate ;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `appoint_reminder`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `appoint_reminder` ()  NO SQL
BEGIN
    DECLARE apID int;
    DECLARE paID int;
    DECLARE nurID int;
    DECLARE tp VARCHAR(50);
    DECLARE stat VARCHAR(50);
    DECLARE pname VARCHAR(60);
    DECLARE dt datetime;
    
    DECLARE exitL BOOLEAN DEFAULT FALSE;    
    DECLARE getAppoit CURSOR FOR SELECT a.apptID,a.patID, (SELECT concat_name(p.firstName,p.lastName)) AS patname, a.nurseID,a.type, a.status, a.date FROM Appointment a, Patient p WHERE a.status = 'pending' AND a.patID=p.patID;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET exitL = TRUE;

-- type, reason, heartRate, sugarLevel, bloodPressure, status, date

    OPEN getAppoit;
    getAll: LOOP
    	FETCH FROM getAppoit INTO apID, paID, pname, nurID, tp, stat, dt;  
        IF exitL THEN
        	LEAVE getAll;
        END IF;
        
        IF (dt >= NOW() AND stat='pending') THEN
        	INSERT INTO PatientMsg(patID,type,message) VALUES(paID, 'Appointment', CONCAT(pname,': You have the follow up appointment type: ',tp,' AT - ',dt ));
            INSERT INTO NurseMsg(nurseID, type, message) VALUES(nurID,'Appointment', CONCAT('You have the follow up appointment with: ',pname,' AT - ',dt));
        ELSEIF (dt < NOW() AND stat='pending') THEN
        	INSERT INTO NurseMsg(nurseID, type, message) VALUES(nurID,'Missed appointment', CONCAT('You have a missed appointment with: ',pname,' AT - ',dt));
            UPDATE Appointment SET status='inactive' WHERE apptID = apID;
        END IF;
    END LOOP getAll;
	CLOSE getAppoit;
END$$

DROP PROCEDURE IF EXISTS `appoint_select`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `appoint_select` (IN `clincID` INT, IN `actionT` VARCHAR(45), IN `searchWord` VARCHAR(128))  NO SQL
BEGIN
	DECLARE me VARCHAR(255);
    IF (actionT = 'selectDoctor') THEN
    	SELECT c.clinID, CONCAT(c.firstName," ",c.lastName) AS fullname, c.designation, c.email, c.cellphone, CONCAT(c.address,", ",c.city) AS address  FROM Clinician c WHERE ( LOWER(c.firstName) LIKE  LOWER(CONCAT("%",searchWord,"%")) OR LOWER(c.lastName) LIKE  LOWER(CONCAT("%",searchWord,"%")) OR LOWER(c.designation) LIKE  LOWER(CONCAT("%",searchWord,"%")) ) AND c.clinicID=clincID AND c.status='active' LIMIT 20;
    	-- LEAVE appoint_select_worker; CONCAT("%",searchWord,"%")
    END IF;
    
    IF (actionT = 'selectAppoint') THEN
    	SELECT a.apptID, (SELECT CONCAT(p.firstName,' ',p.lastName) FROM Patient p WHERE p.patID = a.patID) AS patName,
        (SELECT CONCAT(c.firstName,' ',c.lastName) FROM Clinician c WHERE c.clinID = a.clinID) AS clinName,
        (SELECT CONCAT(n.firstName,' ',n.lastName) FROM Nurse n WHERE n.nurseID = a.nurseID) AS nurseName, a.staffInfo, a.type, a.reason, a.heartRate, a.sugarLevel, a.bloodPressure, a.status, a.date FROM Appointment a, Clinician c WHERE a.clinID = c.clinID AND c.clinicID = clincID ORDER BY FIELD(a.status,'pending','active','inactive'), a.apptID DESC;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `insert_Patient`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_Patient` (IN `clinic` INT, IN `fName` VARCHAR(45), IN `lName` VARCHAR(45), IN `addr` VARCHAR(128), IN `city` VARCHAR(45), IN `cell` VARCHAR(45), IN `mail` VARCHAR(128), IN `status` VARCHAR(45))  NO SQL
BEGIN
	SET @res = (SELECT email FROM Patient WHERE email = mail);
	IF  (@res IS NULL) THEN
        INSERT INTO Patient(clinicID,firstName,lastName, address, city,cellphone,email,status) VALUES(clinic, fName, lName, addr, city, cell, mail, status); 
		SELECT 1 AS result;
    ELSE
    	SELECT -1 AS result;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `login`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `login` (IN `emailAd` VARCHAR(255), IN `passAd` VARCHAR(255))  NO SQL
BEGIN

	SET @resultAdmin = (SELECT JSON_OBJECT('adminID',adminID, 'clinicID',clinicID, 'category',category, 'firstName',firstName, 'lastName',lastName, 'address',address, 'cellphone', cellphone, 'email',email, 'password',password, 'status',status, 'date',date) FROM Admin WHERE email=emailAd AND password=passAd );

    SET @resultClinician = (SELECT JSON_OBJECT('clinID',clinID, 'clinicID',clinicID, 'firstName',firstName, 'lastName',lastName, 'designation',designation, 'address',address, 'city',city, 'cellphone',cellphone, 'email',email, 'password',password, 'status',status, 'date',date) FROM Clinician WHERE email=emailAd AND password=passAd );
    
    SET @resultLabTech = (SELECT JSON_OBJECT('techID',techID, 'clinicID',clinicID, 'firstName',firstName, 'lastName',lastName, 'designation',designation, 'address',address, 'city',city, 'cellphone',cellphone, 'email',email, 'password',password, 'status',status, 'date',date) FROM LabTech WHERE email=emailAd AND password=passAd );
       
    SET @resultNurse = (SELECT JSON_OBJECT('nurseID',nurseID, 'clinicID',clinicID, 'firstName',firstName, 'lastName',lastName, 'designation',designation, 'address',address, 'city',city, 'cellphone',cellphone, 'email',email, 'password',password, 'status',status, 'date',date) FROM Nurse WHERE email=emailAd AND password=passAd );
    
    SET @resultPharmaceutist = (SELECT JSON_OBJECT('pharID',pharID, 'clinicID',clinicID, 'firstName',firstName, 'lastName',lastName, 'designation',designation, 'address',address, 'cellphone',cellphone, 'email',email, 'password',password, 'status',status, 'date',date) FROM Pharmaceutist WHERE email=emailAd AND password=passAd );
    
    SET @resultReceptionist = (SELECT JSON_OBJECT('recepID',recepID, 'clinicID',clinicID, 'firstName',firstName, 'lastName',lastName, 'address',address, 'cellphone',cellphone, 'email',email, 'password',password, 'status',status, 'date',date) FROM Receptionist WHERE email=emailAd AND password=passAd );

    IF JSON_LENGTH(@resultAdmin) > 0 THEN
        SELECT JSON_MERGE_PRESERVE('{"user": "Admin"}', @resultAdmin) AS result;
    ELSEIF JSON_LENGTH(@resultClinician) > 0 THEN
    	SELECT JSON_MERGE_PRESERVE('{"user": "Clinician"}', @resultClinician) AS result;
    ELSEIF JSON_LENGTH(@resultLabTech) > 0 THEN
    	SELECT JSON_MERGE_PRESERVE('{"user": "LabTech"}', @resultLabTech) AS result;
    ELSEIF JSON_LENGTH(@resultNurse) > 0 THEN
    	SELECT JSON_MERGE_PRESERVE('{"user": "Nurse"}', @resultNurse) AS result;
    ELSEIF JSON_LENGTH(@resultPharmaceutist) > 0 THEN
    	SELECT JSON_MERGE_PRESERVE('{"user": "Pharma"}', @resultPharmaceutist) AS result;
    ELSEIF JSON_LENGTH(@resultReceptionist) > 0 THEN
    	SELECT JSON_MERGE_PRESERVE('{"user": "Recep"}', @resultReceptionist) AS result;
    ELSE
        SELECT JSON_OBJECT('user', 'fail') AS result;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `log_ex`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `log_ex` ()  NO SQL
BEGIN
	DECLARE result JSON;
	-- SELECT adminID,clinicID,category, firstName, lastName, address,cellphone,email,password
    -- FROM Admin WHERE email = emailAd AND password = passAd;
    	-- SELECT a.adminID FROM Admin a ORDER BY RAND() limit 1;
    -- INSERT INTO Nurse(clinicID, firstName, lastName, designation, address, city, cellphone, email, password) VALUES ('bruno','Lac', 'nurse','Worth','CapeTown', '3495900503','brun@gmail.com','bruno');
	-- SELECT ROW_COUNT();
    -- SET @result = (SELECT testFunction('m','Suquila'));
    -- SELECT @result;
    
    SET @result = JSON_OBJECT('key1', 1, 'key2', 'abc');
    -- SELECT JSON_OBJECT('key1', 1, 'key2', 'abc') AS result;
    -- SELECT @result AS result;
    SELECT JSON_LENGTH(@result) AS Result;
END$$

DROP PROCEDURE IF EXISTS `tables_select`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tables_select` (IN `act` VARCHAR(45), IN `hpID` INT, IN `iduser` INT)  NO SQL
BEGIN
IF (act = 'labtech') THEN
	SELECT * FROM labtechs WHERE clinicID=hpID ORDER BY techID DESC;

ELSEIF (act = 'nurse') THEN
	SELECT * FROM nurses WHERE clinicID=hpID ORDER BY nurseID DESC;
    
ELSEIF (act = 'admin') THEN
	SELECT * FROM admins WHERE clinicID=hpID ORDER BY adminID DESC;
    
ELSEIF (act = 'pharma') THEN
	SELECT * FROM pharmaceutists WHERE clinicID=hpID ORDER BY pharID DESC;
    
ELSEIF (act = 'recep') THEN
	SELECT * FROM receptionists WHERE clinicID=hpID ORDER BY recepID DESC;
    
ELSEIF (act = 'testrequest') THEN
	SELECT * FROM Lab b WHERE b.consID=iduser LIMIT 1;
    
ELSEIF (act = 'getPresc') THEN
	SELECT * FROM Prescription WHERE consID=idCons LIMIT 1;

ELSEIF (act = 'clinic') THEN
	SELECT * FROM Clinic ORDER BY id DESC;
    
-- ELSEIF (act = 'selpat') THEN
	-- SELECT a.patID FROM Lab l, Consultation c, Appointment a WHERE l.consID=c.consID AND c.consID=iduser AND c.apptID=a.apptID LIMIT 1;
-- ELSE
	-- SELECT (SELECT concat_name('W','K') ) AS result;
END IF;
END$$

--
-- Functions
--
DROP FUNCTION IF EXISTS `concat_name`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `concat_name` (`fval` VARCHAR(50), `sval` VARCHAR(50)) RETURNS VARCHAR(100) CHARSET utf8 NO SQL
RETURN CONCAT(fval," ",sval)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--

DROP TABLE IF EXISTS `Admin`;
CREATE TABLE IF NOT EXISTS `Admin` (
  `adminID` int(11) NOT NULL AUTO_INCREMENT,
  `clinicID` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `firstName` varchar(45) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lastName` varchar(45) COLLATE utf8_bin NOT NULL DEFAULT '',
  `address` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `cellphone` varchar(45) COLLATE utf8_bin NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `password` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`adminID`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `clinicID` (`clinicID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Admin`
--

INSERT INTO `Admin` (`adminID`, `clinicID`, `category`, `firstName`, `lastName`, `address`, `cellphone`, `email`, `password`, `status`, `date`) VALUES
(1, 1, 1, 'Mpumi', 'Sheni', 'Claremont/Cape Town', '0790352734', 'mpumi@gmail.com', 'mpumi', 'active', '2020-05-30 12:28:37'),
(2, 2, 1, 'Reto', 'Mtala', 'Table View/Cape Town', '0790352734', 'reto@gmail.com', 'reto', 'active', '2020-05-30 12:28:37'),
(3, 1, 1, 'Polo', 'Mac', 'Kenilworth', '3495900503', 'polo@gmail.com', 'polo', 'inactive', '2020-06-01 04:39:41');

-- --------------------------------------------------------

--
-- Stand-in structure for view `admins`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
`adminID` int(11)
,`clinicID` int(11)
,`category` int(11)
,`firstName` varchar(45)
,`lastName` varchar(45)
,`address` varchar(100)
,`cellphone` varchar(45)
,`email` varchar(255)
,`password` varchar(255)
,`status` enum('active','inactive')
,`date` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `Appointment`
--

DROP TABLE IF EXISTS `Appointment`;
CREATE TABLE IF NOT EXISTS `Appointment` (
  `apptID` int(11) NOT NULL AUTO_INCREMENT,
  `patID` int(11) NOT NULL DEFAULT 0,
  `staffInfo` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `clinID` int(11) NOT NULL DEFAULT 0,
  `nurseID` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `reason` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `heartRate` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `sugarLevel` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `bloodPressure` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `status` enum('active','inactive','pending') COLLATE utf8_bin NOT NULL DEFAULT 'pending',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`apptID`),
  KEY `patID_fgr` (`patID`),
  KEY `nurseID_fgr` (`nurseID`),
  KEY `clinID_fgr` (`clinID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Appointment`
--

INSERT INTO `Appointment` (`apptID`, `patID`, `staffInfo`, `clinID`, `nurseID`, `type`, `reason`, `heartRate`, `sugarLevel`, `bloodPressure`, `status`, `date`) VALUES
(1, 1, 'Admin: ID(1)', 1, 1, ' mental', 'extract all', '4 hr/s', '3 ml', '13 bp', 'inactive', '2020-06-06 16:21:26'),
(2, 3, 'Recep: ID(1)', 2, 2, 'cut', 'legs', '  no', '  no', '  no', 'pending', '2020-06-05 16:55:00'),
(3, 3, 'clinician: ID(1)', 1, 4, 'dentist', 'extract', ' 2 hr/s', '5 ml', '14 bp', 'pending', '2020-06-07 16:51:00'),
(4, 3, 'admin: ID(1)', 2, 2, 'sd', 'sd', '  no', '  no', '  no', 'active', '2020-06-07 17:27:00'),
(5, 4, 'Recep: ID(1)', 3, 2, 'Headache', 'Getting Headaches everyday', '23', '41', '20', 'inactive', '2020-06-13 10:00:00'),
(6, 5, 'Recep: ID(1)', 3, 4, 'Head', 'Head', 'no', 'no', 'no', 'pending', '2020-06-14 10:50:00');

--
-- Triggers `Appointment`
--
DROP TRIGGER IF EXISTS `oninsert_appoint`;
DELIMITER $$
CREATE TRIGGER `oninsert_appoint` AFTER INSERT ON `Appointment` FOR EACH ROW INSERT INTO PatientMsg(patID,type,message) VALUES(NEW.patID, 'Appointment',CONCAT('You have been successfully scheduled for appointment - ',NEW.date))
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `Clinic`
--

DROP TABLE IF EXISTS `Clinic`;
CREATE TABLE IF NOT EXISTS `Clinic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_bin NOT NULL,
  `location` varchar(100) COLLATE utf8_bin NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Clinic`
--

INSERT INTO `Clinic` (`id`, `name`, `location`, `status`, `date`) VALUES
(1, 'Claremont Branch', 'Cape Town', 'active', '2020-05-30 12:17:57'),
(2, 'CapeTown Branch', 'Cape Town', 'active', '2020-05-30 12:18:17'),
(3, 'TableView Branch', 'Cape Town', 'active', '2020-05-30 12:18:48');

-- --------------------------------------------------------

--
-- Table structure for table `Clinician`
--

DROP TABLE IF EXISTS `Clinician`;
CREATE TABLE IF NOT EXISTS `Clinician` (
  `clinID` int(11) NOT NULL AUTO_INCREMENT,
  `clinicID` int(11) NOT NULL,
  `firstName` varchar(45) COLLATE utf8_bin NOT NULL,
  `lastName` varchar(45) COLLATE utf8_bin NOT NULL,
  `designation` varchar(128) COLLATE utf8_bin NOT NULL,
  `address` varchar(45) COLLATE utf8_bin NOT NULL,
  `city` varchar(45) COLLATE utf8_bin NOT NULL,
  `cellphone` varchar(45) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`clinID`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `clinicID_fg` (`clinicID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Clinician`
--

INSERT INTO `Clinician` (`clinID`, `clinicID`, `firstName`, `lastName`, `designation`, `address`, `city`, `cellphone`, `email`, `password`, `status`, `date`) VALUES
(1, 1, 'Malungo', 'Boom', 'Dentist', 'Claremontt', 'Cape Town', '0790352734', 'malungo@gmail.com', 'malungo', 'active', '2020-05-30 12:53:45'),
(2, 2, 'Fabio', 'Doom', 'GP', 'Claremont', 'Cape Town', '0790352734', 'fabio@gmail.com', 'fabio', 'active', '2020-06-05 04:05:57'),
(3, 1, 'Mateu', 'Front', 'GP', 'Claremont', 'Cape Town', '0790352734', 'mateu@gmail.com', 'mateu', 'active', '2020-06-09 16:24:12');

-- --------------------------------------------------------

--
-- Stand-in structure for view `clinicians`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `clinicians`;
CREATE TABLE IF NOT EXISTS `clinicians` (
`clinID` int(11)
,`clinicID` int(11)
,`firstName` varchar(45)
,`lastName` varchar(45)
,`designation` varchar(128)
,`address` varchar(45)
,`city` varchar(45)
,`cellphone` varchar(45)
,`email` varchar(255)
,`password` varchar(255)
,`status` enum('active','inactive')
,`date` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `Consultation`
--

DROP TABLE IF EXISTS `Consultation`;
CREATE TABLE IF NOT EXISTS `Consultation` (
  `consID` int(11) NOT NULL AUTO_INCREMENT,
  `apptID` int(11) NOT NULL DEFAULT 0,
  `consDetails` text COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `consReport` text COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `status` enum('active','inactive','complete') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`consID`),
  KEY `apptID_fg` (`apptID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Consultation`
--

INSERT INTO `Consultation` (`consID`, `apptID`, `consDetails`, `consReport`, `status`, `date`) VALUES
(1, 1, 'PATIENT: Didi Marvel.\r\nTYPE: mental.\r\nREASON: extract all.\r\nHEART RATE: 4 hr/s.\r\nSUGAR LEVEL: 3 ml.\r\nBLOOD PRESSURE: 13 bp.\r\n\r\nMalungo Boom - ADDITIONAL INFO:\r\n\r\n\r\n', 'Malungo Boom - REPORT:\r\n\r\n\r\n', 'complete', '2020-06-10 02:44:38'),
(2, 1, 'PATIENT: Didi Marvel.\r\nTYPE: mental.\r\nREASON: extract all.\r\nHEART RATE: 4 hr/s.\r\nSUGAR LEVEL: 3 ml.\r\nBLOOD PRESSURE: 13 bp.\r\n\r\nMalungo Boom - ADDITIONAL INFO:\r\n\r\n\r\n\r\n\r\n', 'Malungo Boom - REPORT:\r\n\r\n\r\n\r\n\r\n', 'inactive', '2020-06-10 02:31:51'),
(3, 2, 'PATIENT: Didi Marvel.\r\nTYPE: mental.\r\nREASON: extract all.\r\nHEART RATE: 4 hr/s.\r\nSUGAR LEVEL: 3 ml.\r\nBLOOD PRESSURE: 13 bp.\r\n\r\nMalungo Boom - ADDITIONAL INFO:\r\n', 'Malungo Boom - REPORT:\r\n', 'inactive', '2020-06-10 02:40:38'),
(4, 1, 'PATIENT: Didi Marvel.\r\nTYPE: mental.\r\nREASON: extract all.\r\nHEART RATE: 4 hr/s.\r\nSUGAR LEVEL: 3 ml.\r\nBLOOD PRESSURE: 13 bp.\r\n\r\nMalungo Boom - ADDITIONAL INFO:\r\ntesting it', 'Malungo Boom - REPORT:\r\ntest taken', 'inactive', '2020-06-10 04:26:06'),
(5, 1, 'PATIENT: Didi Marvel.\r\nTYPE: mental.\r\nREASON: extract all.\r\nHEART RATE: 4 hr/s.\r\nSUGAR LEVEL: 3 ml.\r\nBLOOD PRESSURE: 13 bp.\r\n\r\nMalungo Boom - ADDITIONAL INFO:\r\nupall\r\n\r\n\r\n\r\n\r\n\r\n\r\n', 'Malungo Boom - REPORT:\r\nUplo\r\n\r\n\r\n\r\n', 'inactive', '2020-06-10 04:44:03'),
(6, 1, 'PATIENT: Didi Marvel.\r\nTYPE: mental.\r\nREASON: extract all.\r\nHEART RATE: 4 hr/s.\r\nSUGAR LEVEL: 3 ml.\r\nBLOOD PRESSURE: 13 bp.\r\n\r\nMalungo Boom - ADDITIONAL INFO:\r\nHe feel like..\r\n\r\n', 'Malungo Boom - REPORT:\r\nThis person has\r\n\r\n', 'inactive', '2020-06-10 22:56:55'),
(7, 1, 'PATIENT: Didi Marvel.\r\nTYPE: mental.\r\nREASON: extract all.\r\nHEART RATE: 4 hr/s.\r\nSUGAR LEVEL: 3 ml.\r\nBLOOD PRESSURE: 13 bp.\r\n\r\nMalungo Boom - ADDITIONAL INFO:\r\nHe has feelings\r\n\r\n\r\n', 'Malungo Boom - REPORT:\r\nthis is the last\r\n\r\n\r\n', 'complete', '2020-06-10 23:07:30'),
(8, 5, 'PATIENT: Mateu Lope.\r\nTYPE:Headache.\r\nREASON: Getting Headaches everyday.\r\nHEART RATE: 23.\r\nSUGAR LEVEL: 41.\r\nBLOOD PRESSURE: 20.\r\n\r\nMateu Front - ADDITIONAL INFO:\r\nThe patient had blood issues..', 'Mateu Front - REPORT:\r\nThis headache is nothing', 'complete', '2020-06-13 08:34:54');

-- --------------------------------------------------------

--
-- Table structure for table `Lab`
--

DROP TABLE IF EXISTS `Lab`;
CREATE TABLE IF NOT EXISTS `Lab` (
  `labID` int(11) NOT NULL AUTO_INCREMENT,
  `consID` int(11) NOT NULL DEFAULT 0,
  `techID` int(11) NOT NULL DEFAULT 0,
  `testRequested` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `testInfo` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `testResult` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `testConfirmed` enum('pregnancy','hiv','diabete','other','no') COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `status` enum('active','inactive','complete') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`labID`),
  KEY `techID_fg` (`techID`),
  KEY `consID_fg` (`consID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Lab`
--

INSERT INTO `Lab` (`labID`, `consID`, `techID`, `testRequested`, `testInfo`, `testResult`, `testConfirmed`, `status`, `date`) VALUES
(1, 5, 0, 'Blood test and eye.', 'Test if his blood has infection...', '', 'no', 'inactive', '2020-06-13 08:43:05'),
(2, 6, 3, 'Blodd test', 'ASAP', 'cd', 'no', 'active', '2020-06-12 09:16:03'),
(3, 7, 1, 'blood test and fill..', 'urgent!', 'sdddddd...', 'no', 'active', '2020-06-12 09:16:24'),
(4, 8, 3, 'Blood test', 'ASAP - We need it to continue...', 'pregnancy', 'pregnancy', 'active', '2020-06-13 17:26:31');

--
-- Triggers `Lab`
--
DROP TRIGGER IF EXISTS `insert_lab_result_info`;
DELIMITER $$
CREATE TRIGGER `insert_lab_result_info` BEFORE UPDATE ON `Lab` FOR EACH ROW if (NEW.testConfirmed = 'pregnancy') THEN 
	INSERT INTO MomConnect(labID, consID, message) VALUES(OLD.labID,OLD.consID, 'You have been successfully registered to MomConnect');
END IF
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `LabTech`
--

DROP TABLE IF EXISTS `LabTech`;
CREATE TABLE IF NOT EXISTS `LabTech` (
  `techID` int(11) NOT NULL AUTO_INCREMENT,
  `clinicID` int(11) NOT NULL,
  `firstName` varchar(45) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lastName` varchar(45) COLLATE utf8_bin NOT NULL DEFAULT '',
  `designation` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `address` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `city` varchar(45) COLLATE utf8_bin NOT NULL DEFAULT '',
  `cellphone` varchar(45) COLLATE utf8_bin NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `password` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`techID`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `clinicID` (`clinicID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `LabTech`
--

INSERT INTO `LabTech` (`techID`, `clinicID`, `firstName`, `lastName`, `designation`, `address`, `city`, `cellphone`, `email`, `password`, `status`, `date`) VALUES
(1, 1, 'Miguel', 'Mar', 'Lab technician', 'Wood', 'Cape Town', '0790352734', 'miguel@gmail.com', 'miguel', 'active', '2020-05-30 13:00:27'),
(2, 2, 'Mata', 'Marc', 'Lab technician', 'Wood', 'Cape Town', '0790352734', 'mata@gmail.com', 'mata', 'active', '2020-06-09 17:58:59'),
(3, 1, 'Neto', 'Mell', 'Lab technician', 'Wood', 'Cape Town', '0790352734', 'neto@gmail.com', 'neto', 'active', '2020-06-12 07:50:13');

-- --------------------------------------------------------

--
-- Stand-in structure for view `labtechs`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `labtechs`;
CREATE TABLE IF NOT EXISTS `labtechs` (
`techID` int(11)
,`clinicID` int(11)
,`firstName` varchar(45)
,`lastName` varchar(45)
,`designation` varchar(100)
,`address` varchar(100)
,`city` varchar(45)
,`cellphone` varchar(45)
,`email` varchar(255)
,`password` varchar(255)
,`status` enum('active','inactive')
,`date` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `MomConnect`
--

DROP TABLE IF EXISTS `MomConnect`;
CREATE TABLE IF NOT EXISTS `MomConnect` (
  `momConID` int(11) NOT NULL AUTO_INCREMENT,
  `labID` int(11) NOT NULL DEFAULT 0,
  `consID` int(11) NOT NULL DEFAULT 0,
  `message` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`momConID`),
  KEY `labID_fg` (`labID`),
  KEY `patID_fg` (`consID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `MomConnect`
--

INSERT INTO `MomConnect` (`momConID`, `labID`, `consID`, `message`, `status`, `date`) VALUES
(1, 4, 8, 'You have been successfully registered to MomConnect', 'active', '2020-06-13 17:26:13'),
(2, 4, 8, 'You have been successfully registered to MomConnect', 'active', '2020-06-13 17:26:31');

-- --------------------------------------------------------

--
-- Table structure for table `Nurse`
--

DROP TABLE IF EXISTS `Nurse`;
CREATE TABLE IF NOT EXISTS `Nurse` (
  `nurseID` int(11) NOT NULL AUTO_INCREMENT,
  `clinicID` int(11) NOT NULL,
  `firstName` varchar(45) COLLATE utf8_bin NOT NULL,
  `lastName` varchar(45) COLLATE utf8_bin NOT NULL,
  `designation` varchar(128) COLLATE utf8_bin NOT NULL,
  `address` varchar(45) COLLATE utf8_bin NOT NULL,
  `city` varchar(45) COLLATE utf8_bin NOT NULL,
  `cellphone` varchar(45) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`nurseID`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `clinicID` (`clinicID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Nurse`
--

INSERT INTO `Nurse` (`nurseID`, `clinicID`, `firstName`, `lastName`, `designation`, `address`, `city`, `cellphone`, `email`, `password`, `status`, `date`) VALUES
(1, 1, 'Duplo', 'Lac', 'nurse high', 'Cape', 'Cape Town', '3495900503', 'duplo@gmail.com', 'duplo', 'active', '2020-06-02 00:58:39'),
(2, 1, 'bruno', 'Lac', 'nurse', 'Worth', 'CapeTown', '3495900503', 'bruno@gmail.com', 'bruno', 'active', '2020-06-07 02:53:02'),
(4, 2, 'bruno', 'Lac', 'nurse', 'Worth', 'CapeTown', '3495900503', 'brun@gmail.com', 'bruno', 'active', '2020-06-07 02:53:56');

-- --------------------------------------------------------

--
-- Table structure for table `NurseMsg`
--

DROP TABLE IF EXISTS `NurseMsg`;
CREATE TABLE IF NOT EXISTS `NurseMsg` (
  `nurMsgID` int(11) NOT NULL AUTO_INCREMENT,
  `nurseID` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `message` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`nurMsgID`),
  KEY `nurseID_fg` (`nurseID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `NurseMsg`
--

INSERT INTO `NurseMsg` (`nurMsgID`, `nurseID`, `type`, `message`, `status`, `date`) VALUES
(1, 4, 'Appointment', 'You have the follow up appointment with: Titi Tito AT - 2020-06-14 10:50:00', 'active', '2020-06-13 23:01:32');

-- --------------------------------------------------------

--
-- Stand-in structure for view `nurses`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `nurses`;
CREATE TABLE IF NOT EXISTS `nurses` (
`nurseID` int(11)
,`clinicID` int(11)
,`firstName` varchar(45)
,`lastName` varchar(45)
,`designation` varchar(128)
,`address` varchar(45)
,`city` varchar(45)
,`cellphone` varchar(45)
,`email` varchar(255)
,`password` varchar(255)
,`status` enum('active','inactive')
,`date` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `Patient`
--

DROP TABLE IF EXISTS `Patient`;
CREATE TABLE IF NOT EXISTS `Patient` (
  `patID` int(11) NOT NULL AUTO_INCREMENT,
  `clinicID` int(11) NOT NULL,
  `firstName` varchar(45) COLLATE utf8_bin NOT NULL,
  `lastName` varchar(45) COLLATE utf8_bin NOT NULL,
  `address` varchar(128) COLLATE utf8_bin NOT NULL,
  `city` varchar(45) COLLATE utf8_bin NOT NULL,
  `cellphone` varchar(45) COLLATE utf8_bin NOT NULL,
  `email` varchar(128) COLLATE utf8_bin NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`patID`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `clinicID` (`clinicID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Patient`
--

INSERT INTO `Patient` (`patID`, `clinicID`, `firstName`, `lastName`, `address`, `city`, `cellphone`, `email`, `status`, `date`) VALUES
(1, 1, 'Didi', 'Marvel', 'Salt River', 'Cape Town', '0790352734', 'didi@gmail.com', 'active', '2020-05-30 13:07:32'),
(2, 3, 'Gugu', 'Bat', 'Rond', 'Cape Town', '8738478838', 'gugu@gmail.com', 'active', '2020-06-03 18:12:46'),
(3, 2, 'Kadu Du', 'bbbbs', 'CP', 'cape', '34i4j8j48', 'carlosdo@gmail.com', 'inactive', '2020-06-04 02:54:47'),
(4, 1, 'Mateu', 'Lope', 'Braga', 'Cape Town', '0448594829', 'mateu@gmail.com', 'active', '2020-06-13 08:13:51'),
(5, 1, 'Titi', 'Tito', 'Cape', 'Cape Town', '0448594829', 'titi@gmail.com', 'active', '2020-06-13 13:48:12');

--
-- Triggers `Patient`
--
DROP TRIGGER IF EXISTS `insert_confirmation`;
DELIMITER $$
CREATE TRIGGER `insert_confirmation` AFTER INSERT ON `Patient` FOR EACH ROW INSERT INTO PatientMsg(patID,type,message) VALUES(NEW.patID, 'Registration',CONCAT('You (',NEW.firstName,' ',NEW.lastName,') have been successfully registered to BroadReach System.'))
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `PatientMsg`
--

DROP TABLE IF EXISTS `PatientMsg`;
CREATE TABLE IF NOT EXISTS `PatientMsg` (
  `patMsgID` int(11) NOT NULL AUTO_INCREMENT,
  `patID` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `message` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`patMsgID`),
  KEY `patID_foreign` (`patID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `PatientMsg`
--

INSERT INTO `PatientMsg` (`patMsgID`, `patID`, `type`, `message`, `status`, `date`) VALUES
(1, 5, 'Registration', 'You (Titi Tito) have been successfully registered', 'active', '2020-06-13 13:48:12'),
(2, 5, 'Appointment', 'You have been successfully scheduled for appointment - 2020-06-14 10:50:00', 'active', '2020-06-13 17:38:38');

-- --------------------------------------------------------

--
-- Stand-in structure for view `patients`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `patients`;
CREATE TABLE IF NOT EXISTS `patients` (
`patID` int(11)
,`clinicID` int(11)
,`firstName` varchar(45)
,`lastName` varchar(45)
,`address` varchar(128)
,`city` varchar(45)
,`cellphone` varchar(45)
,`email` varchar(128)
,`status` enum('active','inactive')
,`date` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `Pharmaceutist`
--

DROP TABLE IF EXISTS `Pharmaceutist`;
CREATE TABLE IF NOT EXISTS `Pharmaceutist` (
  `pharID` int(11) NOT NULL AUTO_INCREMENT,
  `clinicID` int(11) NOT NULL,
  `firstName` varchar(45) COLLATE utf8_bin NOT NULL,
  `lastName` varchar(45) COLLATE utf8_bin NOT NULL,
  `designation` varchar(100) COLLATE utf8_bin NOT NULL,
  `address` varchar(100) COLLATE utf8_bin NOT NULL,
  `cellphone` varchar(45) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`pharID`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `clinicID` (`clinicID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Pharmaceutist`
--

INSERT INTO `Pharmaceutist` (`pharID`, `clinicID`, `firstName`, `lastName`, `designation`, `address`, `cellphone`, `email`, `password`, `status`, `date`) VALUES
(1, 1, 'Mbondi', 'Perlo', 'Technician', 'Cape Town', '0790352734', 'mbondi@gmail.com', 'mbondi', 'active', '2020-05-30 13:18:01'),
(2, 1, 'Lodi', 'Pepe', 'Pharmaceutist', 'Cape Town', '0790352734', 'lodi@gmail.com', 'lodi', 'active', '2020-06-13 02:52:06');

-- --------------------------------------------------------

--
-- Stand-in structure for view `pharmaceutists`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `pharmaceutists`;
CREATE TABLE IF NOT EXISTS `pharmaceutists` (
`pharID` int(11)
,`clinicID` int(11)
,`firstName` varchar(45)
,`lastName` varchar(45)
,`designation` varchar(100)
,`address` varchar(100)
,`cellphone` varchar(45)
,`email` varchar(255)
,`password` varchar(255)
,`status` enum('active','inactive')
,`date` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `Prescription`
--

DROP TABLE IF EXISTS `Prescription`;
CREATE TABLE IF NOT EXISTS `Prescription` (
  `prescID` int(11) NOT NULL AUTO_INCREMENT,
  `consID` int(11) NOT NULL DEFAULT 0,
  `patID` int(11) NOT NULL DEFAULT 0,
  `clinID` int(11) NOT NULL DEFAULT 0,
  `pharID` int(11) NOT NULL DEFAULT 0,
  `drug_name` text COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `drug_purpose` text COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `dosage` text COLLATE utf8_bin NOT NULL DEFAULT 'no',
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`prescID`),
  KEY `consID_fg` (`consID`),
  KEY `patID_fg` (`patID`),
  KEY `clinID_fg` (`clinID`),
  KEY `pharID` (`pharID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Prescription`
--

INSERT INTO `Prescription` (`prescID`, `consID`, `patID`, `clinID`, `pharID`, `drug_name`, `drug_purpose`, `dosage`, `status`, `date`) VALUES
(1, 5, 1, 1, 1, 'panado and flex and it.', 'relief headache...', 'Take one pill a day, no more than this.\n\nPharmaceutist (Mbondi Perlo) Info:\nWe had to change to parace.\n\nPharmaceutist (Mbondi Perlo) Info:\nAdded honey..\n\nPharmaceutist (Mbondi Perlo) Info:\nChanged it too..\n\nAdmin Info:\nAdd it\n\nPharmaceutist (Mbondi Perlo) Info:\nchage', 'inactive', '2020-06-10 04:44:03'),
(2, 7, 1, 1, 1, 'panado', 'relief', '1 pill a day...\n\nPharmaceutist (Mbondi Perlo) Info:\nAdd honey', 'inactive', '2020-06-11 04:09:35'),
(3, 8, 4, 3, 1, 'panado', 'relief', '1 tablet a day\n\nPharmaceutist (Mbondi Perlo) Info:\nWe gave paracetamol too', 'inactive', '2020-06-13 08:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `Receptionist`
--

DROP TABLE IF EXISTS `Receptionist`;
CREATE TABLE IF NOT EXISTS `Receptionist` (
  `recepID` int(11) NOT NULL AUTO_INCREMENT,
  `clinicID` int(11) NOT NULL,
  `firstName` varchar(45) COLLATE utf8_bin NOT NULL,
  `lastName` varchar(45) COLLATE utf8_bin NOT NULL,
  `address` varchar(45) COLLATE utf8_bin NOT NULL,
  `cellphone` varchar(45) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8_bin NOT NULL DEFAULT 'active',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`recepID`),
  KEY `clinicID` (`clinicID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Receptionist`
--

INSERT INTO `Receptionist` (`recepID`, `clinicID`, `firstName`, `lastName`, `address`, `cellphone`, `email`, `password`, `status`, `date`) VALUES
(1, 1, 'Gold', 'Kerpo', 'Rondebosch', '0740362333', 'gold@gmail.com', 'gold', 'active', '2020-05-30 13:22:20'),
(2, 2, 'Silver', 'Cond', 'Cape', '074036233', 'silver@gmail.com', 'silver', 'active', '2020-06-04 22:58:27');

-- --------------------------------------------------------

--
-- Stand-in structure for view `receptionists`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `receptionists`;
CREATE TABLE IF NOT EXISTS `receptionists` (
`recepID` int(11)
,`clinicID` int(11)
,`firstName` varchar(45)
,`lastName` varchar(45)
,`address` varchar(45)
,`cellphone` varchar(45)
,`email` varchar(255)
,`password` varchar(255)
,`status` enum('active','inactive')
,`date` datetime
);

-- --------------------------------------------------------

--
-- Structure for view `admins`
--
DROP TABLE IF EXISTS `admins`;

DROP VIEW IF EXISTS `admins`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `admins`  AS  select `admin`.`adminID` AS `adminID`,`admin`.`clinicID` AS `clinicID`,`admin`.`category` AS `category`,`admin`.`firstName` AS `firstName`,`admin`.`lastName` AS `lastName`,`admin`.`address` AS `address`,`admin`.`cellphone` AS `cellphone`,`admin`.`email` AS `email`,`admin`.`password` AS `password`,`admin`.`status` AS `status`,`admin`.`date` AS `date` from `admin` where `admin`.`category` = 1 ;

-- --------------------------------------------------------

--
-- Structure for view `clinicians`
--
DROP TABLE IF EXISTS `clinicians`;

DROP VIEW IF EXISTS `clinicians`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clinicians`  AS  select `clinician`.`clinID` AS `clinID`,`clinician`.`clinicID` AS `clinicID`,`clinician`.`firstName` AS `firstName`,`clinician`.`lastName` AS `lastName`,`clinician`.`designation` AS `designation`,`clinician`.`address` AS `address`,`clinician`.`city` AS `city`,`clinician`.`cellphone` AS `cellphone`,`clinician`.`email` AS `email`,`clinician`.`password` AS `password`,`clinician`.`status` AS `status`,`clinician`.`date` AS `date` from `clinician` ;

-- --------------------------------------------------------

--
-- Structure for view `labtechs`
--
DROP TABLE IF EXISTS `labtechs`;

DROP VIEW IF EXISTS `labtechs`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `labtechs`  AS  select `labtech`.`techID` AS `techID`,`labtech`.`clinicID` AS `clinicID`,`labtech`.`firstName` AS `firstName`,`labtech`.`lastName` AS `lastName`,`labtech`.`designation` AS `designation`,`labtech`.`address` AS `address`,`labtech`.`city` AS `city`,`labtech`.`cellphone` AS `cellphone`,`labtech`.`email` AS `email`,`labtech`.`password` AS `password`,`labtech`.`status` AS `status`,`labtech`.`date` AS `date` from `labtech` ;

-- --------------------------------------------------------

--
-- Structure for view `nurses`
--
DROP TABLE IF EXISTS `nurses`;

DROP VIEW IF EXISTS `nurses`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `nurses`  AS  select `nurse`.`nurseID` AS `nurseID`,`nurse`.`clinicID` AS `clinicID`,`nurse`.`firstName` AS `firstName`,`nurse`.`lastName` AS `lastName`,`nurse`.`designation` AS `designation`,`nurse`.`address` AS `address`,`nurse`.`city` AS `city`,`nurse`.`cellphone` AS `cellphone`,`nurse`.`email` AS `email`,`nurse`.`password` AS `password`,`nurse`.`status` AS `status`,`nurse`.`date` AS `date` from `nurse` ;

-- --------------------------------------------------------

--
-- Structure for view `patients`
--
DROP TABLE IF EXISTS `patients`;

DROP VIEW IF EXISTS `patients`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patients`  AS  select `patient`.`patID` AS `patID`,`patient`.`clinicID` AS `clinicID`,`patient`.`firstName` AS `firstName`,`patient`.`lastName` AS `lastName`,`patient`.`address` AS `address`,`patient`.`city` AS `city`,`patient`.`cellphone` AS `cellphone`,`patient`.`email` AS `email`,`patient`.`status` AS `status`,`patient`.`date` AS `date` from `patient` ;

-- --------------------------------------------------------

--
-- Structure for view `pharmaceutists`
--
DROP TABLE IF EXISTS `pharmaceutists`;

DROP VIEW IF EXISTS `pharmaceutists`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pharmaceutists`  AS  select `pharmaceutist`.`pharID` AS `pharID`,`pharmaceutist`.`clinicID` AS `clinicID`,`pharmaceutist`.`firstName` AS `firstName`,`pharmaceutist`.`lastName` AS `lastName`,`pharmaceutist`.`designation` AS `designation`,`pharmaceutist`.`address` AS `address`,`pharmaceutist`.`cellphone` AS `cellphone`,`pharmaceutist`.`email` AS `email`,`pharmaceutist`.`password` AS `password`,`pharmaceutist`.`status` AS `status`,`pharmaceutist`.`date` AS `date` from `pharmaceutist` ;

-- --------------------------------------------------------

--
-- Structure for view `receptionists`
--
DROP TABLE IF EXISTS `receptionists`;

DROP VIEW IF EXISTS `receptionists`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `receptionists`  AS  select `receptionist`.`recepID` AS `recepID`,`receptionist`.`clinicID` AS `clinicID`,`receptionist`.`firstName` AS `firstName`,`receptionist`.`lastName` AS `lastName`,`receptionist`.`address` AS `address`,`receptionist`.`cellphone` AS `cellphone`,`receptionist`.`email` AS `email`,`receptionist`.`password` AS `password`,`receptionist`.`status` AS `status`,`receptionist`.`date` AS `date` from `receptionist` ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Admin`
--
ALTER TABLE `Admin`
  ADD CONSTRAINT `clinicID_fga` FOREIGN KEY (`clinicID`) REFERENCES `Clinic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Appointment`
--
ALTER TABLE `Appointment`
  ADD CONSTRAINT `clinID_fgr` FOREIGN KEY (`clinID`) REFERENCES `Clinician` (`clinID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nurseID_fgr` FOREIGN KEY (`nurseID`) REFERENCES `Nurse` (`nurseID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `patID_fgr` FOREIGN KEY (`patID`) REFERENCES `Patient` (`patID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Clinician`
--
ALTER TABLE `Clinician`
  ADD CONSTRAINT `clinicID_fgc` FOREIGN KEY (`clinicID`) REFERENCES `Clinic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Consultation`
--
ALTER TABLE `Consultation`
  ADD CONSTRAINT `apptID_fg` FOREIGN KEY (`apptID`) REFERENCES `Appointment` (`apptID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Lab`
--
ALTER TABLE `Lab`
  ADD CONSTRAINT `consID_freg` FOREIGN KEY (`consID`) REFERENCES `Consultation` (`consID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `LabTech`
--
ALTER TABLE `LabTech`
  ADD CONSTRAINT `clinicID_fglt` FOREIGN KEY (`clinicID`) REFERENCES `Clinic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `MomConnect`
--
ALTER TABLE `MomConnect`
  ADD CONSTRAINT `consID_frg` FOREIGN KEY (`consID`) REFERENCES `Consultation` (`consID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `labID_frg` FOREIGN KEY (`labID`) REFERENCES `Lab` (`labID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Nurse`
--
ALTER TABLE `Nurse`
  ADD CONSTRAINT `clinicID_fgnu` FOREIGN KEY (`clinicID`) REFERENCES `Clinic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `NurseMsg`
--
ALTER TABLE `NurseMsg`
  ADD CONSTRAINT `nurseID_fg` FOREIGN KEY (`nurseID`) REFERENCES `Nurse` (`nurseID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Patient`
--
ALTER TABLE `Patient`
  ADD CONSTRAINT `clinicID_fgpt` FOREIGN KEY (`clinicID`) REFERENCES `Clinic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `PatientMsg`
--
ALTER TABLE `PatientMsg`
  ADD CONSTRAINT `patID_foreign` FOREIGN KEY (`patID`) REFERENCES `Patient` (`patID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Pharmaceutist`
--
ALTER TABLE `Pharmaceutist`
  ADD CONSTRAINT `clinicID_fgphr` FOREIGN KEY (`clinicID`) REFERENCES `Clinic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Prescription`
--
ALTER TABLE `Prescription`
  ADD CONSTRAINT `clinID_fg` FOREIGN KEY (`clinID`) REFERENCES `Clinician` (`clinID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `consID_fg` FOREIGN KEY (`consID`) REFERENCES `Consultation` (`consID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `patID_fg` FOREIGN KEY (`patID`) REFERENCES `Patient` (`patID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Receptionist`
--
ALTER TABLE `Receptionist`
  ADD CONSTRAINT `clinicID_fgrc` FOREIGN KEY (`clinicID`) REFERENCES `Clinic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

DELIMITER $$
--
-- Events
--
DROP EVENT `Run_Procedure_Daily`$$
CREATE DEFINER=`root`@`localhost` EVENT `Run_Procedure_Daily` ON SCHEDULE EVERY '0 23' DAY_HOUR STARTS '2020-06-13 22:18:32' ENDS '2030-12-31 22:18:32' ON COMPLETION NOT PRESERVE ENABLE DO CALL appoint_reminder()$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
